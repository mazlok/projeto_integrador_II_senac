package com.mycompany.projeto_integrador_pdv;

public class Vendedor {
    String nome;
    int vendas;

}
