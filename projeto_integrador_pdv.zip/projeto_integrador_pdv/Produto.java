package com.mycompany.projeto_integrador_pdv;

public class Produto {
    String nome, tipo;
    int codProduto,quant;

}
