package com.mycompany.projeto_integrador_pdv;

public class Cliente {
    
    String nome,sexo,email,endereco,estadoCivil,dataNasc;    
    int telefone,cpf;

}
